import threading
import json
import socket
from websocket_server import WebsocketServer
from controller import Robot, Keyboard  # 修正：移除重命名

# 常數設定
TIME_STEP = 32
MAX_VELOCITY = 10.0

# 初始化Webots機器人
robot = Robot()

# 初始化鍵盤控制（修正：使用正確初始化方式）
webots_keyboard = Keyboard()
webots_keyboard.enable(TIME_STEP)

# 獲取馬達設備（修正：使用更清晰的命名）
motors = {
    'front_right': robot.getDevice("wheel1"),
    'front_left': robot.getDevice("wheel2"),
    'rear_right': robot.getDevice("wheel3"),
    'rear_left': robot.getDevice("wheel4")
}

# 設定馬達控制模式
for motor in motors.values():
    motor.setPosition(float('inf'))
    motor.setVelocity(0)

def set_wheel_velocity(v1, v2, v3, v4):
    """四輪速度控制函數"""
    motors['front_right'].setVelocity(v1)
    motors['front_left'].setVelocity(v2)
    motors['rear_right'].setVelocity(v3)
    motors['rear_left'].setVelocity(v4)

# 自訂IPv6 WebSocket伺服器
class IPv6WebsocketServer(WebsocketServer):
    def __init__(self, host, port):
        self.address_family = socket.AF_INET6
        super().__init__(host, port)

# WebSocket訊息處理
def on_message(client, server, message):
    try:
        data = json.loads(message)
        direction = data.get("direction")
        velocity = MAX_VELOCITY

        if direction == "UP":
            set_wheel_velocity(velocity, velocity, velocity, velocity)
        elif direction == "DOWN":
            set_wheel_velocity(-velocity, -velocity, -velocity, -velocity)
        elif direction == "LEFT":
            set_wheel_velocity(-velocity, velocity, -velocity, velocity)
        elif direction == "RIGHT":
            set_wheel_velocity(velocity, -velocity, velocity, -velocity)
        elif direction == "STOP":
            set_wheel_velocity(0, 0, 0, 0)
    except Exception as e:
        print(f"指令處理錯誤: {str(e)}")

def start_websocket_server():
    """WebSocket伺服器線程"""
    SERVER_IP = "2001:288:6004:17:fff1:cd25:0000:a021"
    SERVER_PORT = 8081
    
    try:
        server = IPv6WebsocketServer(SERVER_IP, SERVER_PORT)
        server.set_fn_message_received(on_message)
        print(f"WebSocket伺服器已啟動於 [{SERVER_IP}]:{SERVER_PORT}")
        server.run_forever()
    except socket.error as e:
        print(f"網路錯誤: {e}")

def webots_main():
    """主控制循環"""
    print("本地控制：方向鍵移動，Q/ESC退出")
    while robot.step(TIME_STEP) != -1:
        key = webots_keyboard.getKey()
        
        # 使用Webots鍵盤代碼
        if key == 315:  # UP
            set_wheel_velocity(MAX_VELOCITY, MAX_VELOCITY, MAX_VELOCITY, MAX_VELOCITY)
        elif key == 317:  # DOWN
            set_wheel_velocity(-MAX_VELOCITY, -MAX_VELOCITY, -MAX_VELOCITY, -MAX_VELOCITY)
        elif key == 314:  # LEFT
            set_wheel_velocity(-MAX_VELOCITY, MAX_VELOCITY, -MAX_VELOCITY, MAX_VELOCITY)
        elif key == 316:  # RIGHT
            set_wheel_velocity(MAX_VELOCITY, -MAX_VELOCITY, MAX_VELOCITY, -MAX_VELOCITY)
        elif key in [ord('Q'), ord('q'), 27]:  # 退出
            set_wheel_velocity(0, 0, 0, 0)
            break
        else:
            set_wheel_velocity(0, 0, 0, 0)

if __name__ == "__main__":
    # 啟動WebSocket線程
    ws_thread = threading.Thread(target=start_websocket_server, daemon=True)
    ws_thread.start()

    # 啟動主程序
    webots_main()
    print("系統安全關閉")


