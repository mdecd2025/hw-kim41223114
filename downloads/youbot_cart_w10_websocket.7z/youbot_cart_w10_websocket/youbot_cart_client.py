import websocket
import json
import keyboard
import time

def send_command(direction):
    server_ip = "2001:288:6004:17::fffd:c25:0:a021"
    server_port = 8081
    ws_url = f"ws://[{server_ip}]:{server_port}"
    try:
        ws = websocket.create_connection(ws_url)
        message = json.dumps({"direction": direction})
        ws.send(message)
        print(f"Sent command: {direction}")
        ws.close()
    except Exception as e:
        print(f"Failed to send command ({direction}): {e}")

def main():
    print("Use arrow keys or WASD to control the robot. Press 'ESC' or 'q' to quit.")
    while True:
        if keyboard.is_pressed('up') or keyboard.is_pressed('w'):
            send_command('forward')
        elif keyboard.is_pressed('down') or keyboard.is_pressed('s'):
            send_command('backward')
        elif keyboard.is_pressed('right') or keyboard.is_pressed('d'):
            send_command('right')
        elif keyboard.is_pressed('left') or keyboard.is_pressed('a'):
            send_command('left')
        elif keyboard.is_pressed('esc') or keyboard.is_pressed('q'):
            print('Exiting...')
            break
        time.sleep(0.1)

if __name__ == "__main__":
    main()