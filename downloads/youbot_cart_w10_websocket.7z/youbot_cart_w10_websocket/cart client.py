<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>機器人遠端控制</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            background-color: #f0f0f0;
        }
        
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            text-align: center;
        }
        
        .status {
            margin-bottom: 20px;
            padding: 10px;
            border-radius: 5px;
            font-weight: bold;
        }
        
        .connected {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .disconnected {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .control-panel {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            grid-template-rows: 1fr 1fr 1fr;
            gap: 10px;
            width: 240px;
            height: 240px;
            margin: 20px auto;
        }
        
        .control-btn {
            font-size: 18px;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.2s;
            user-select: none;
        }
        
        .control-btn:active {
            transform: scale(0.95);
        }
        
        .up-btn {
            grid-column: 2;
            grid-row: 1;
            background: #007bff;
            color: white;
        }
        
        .left-btn {
            grid-column: 1;
            grid-row: 2;
            background: #28a745;
            color: white;
        }
        
        .stop-btn {
            grid-column: 2;
            grid-row: 2;
            background: #dc3545;
            color: white;
        }
        
        .right-btn {
            grid-column: 3;
            grid-row: 2;
            background: #28a745;
            color: white;
        }
        
        .down-btn {
            grid-column: 2;
            grid-row: 3;
            background: #007bff;
            color: white;
        }
        
        .control-btn:hover {
            opacity: 0.8;
        }
        
        .control-btn:disabled {
            background: #6c757d;
            cursor: not-allowed;
            opacity: 0.5;
        }
        
        .connect-btn {
            padding: 10px 20px;
            font-size: 16px;
            margin: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        
        .connect {
            background: #28a745;
            color: white;
        }
        
        .disconnect {
            background: #dc3545;
            color: white;
        }
        
        .log {
            margin-top: 20px;
            padding: 10px;
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            height: 150px;
            overflow-y: auto;
            text-align: left;
            font-family: monospace;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🤖 機器人遠端控制</h1>
        
        <div id="status" class="status disconnected">
            未連接到機器人
        </div>
        
        <button id="connectBtn" class="connect-btn connect" onclick="toggleConnection()">
            連接
        </button>
        
        <div class="control-panel">
            <button class="control-btn up-btn" id="upBtn" onmousedown="sendCommand('UP')" onmouseup="sendCommand('STOP')" ontouchstart="sendCommand('UP')" ontouchend="sendCommand('STOP')" disabled>
                ↑<br>前進
            </button>
            
            <button class="control-btn left-btn" id="leftBtn" onmousedown="sendCommand('LEFT')" onmouseup="sendCommand('STOP')" ontouchstart="sendCommand('LEFT')" ontouchend="sendCommand('STOP')" disabled>
                ←<br>左轉
            </button>
            
            <button class="control-btn stop-btn" id="stopBtn" onclick="sendCommand('STOP')" disabled>
                ⏹<br>停止
            </button>
            
            <button class="control-btn right-btn" id="rightBtn" onmousedown="sendCommand('RIGHT')" onmouseup="sendCommand('STOP')" ontouchstart="sendCommand('RIGHT')" ontouchend="sendCommand('STOP')" disabled>
                →<br>右轉
            </button>
            
            <button class="control-btn down-btn" id="downBtn" onmousedown="sendCommand('DOWN')" onmouseup="sendCommand('STOP')" ontouchstart="sendCommand('DOWN')" ontouchend="sendCommand('STOP')" disabled>
                ↓<br>後退
            </button>
        </div>
        
        <div id="log" class="log"></div>
    </div>

    <script>
        // WebSocket設定
        const SERVER_IP = "2001:288:6004:17:fff1:cd25:0000:a021";
        const SERVER_PORT = 8081;
        const WS_URL = `ws://[${SERVER_IP}]:${SERVER_PORT}/`;
        
        let websocket = null;
        let isConnected = false;
        
        // DOM元素
        const statusDiv = document.getElementById('status');
        const connectBtn = document.getElementById('connectBtn');
        const logDiv = document.getElementById('log');
        const controlBtns = document.querySelectorAll('.control-btn');
        
        // 日誌函數
        function addLog(message, type = 'info') {
            const timestamp = new Date().toLocaleTimeString();
            const logMessage = `[${timestamp}] ${message}`;
            console.log(logMessage);
            
            const logElement = document.createElement('div');
            logElement.textContent = logMessage;
            logElement.style.color = type === 'error' ? 'red' : type === 'success' ? 'green' : 'black';
            
            logDiv.appendChild(logElement);
            logDiv.scrollTop = logDiv.scrollHeight;
        }
        
        // 更新連接狀態
        function updateConnectionStatus(connected) {
            isConnected = connected;
            
            if (connected) {
                statusDiv.textContent = '✅ 已連接到機器人';
                statusDiv.className = 'status connected';
                connectBtn.textContent = '中斷連接';
                connectBtn.className = 'connect-btn disconnect';
            } else {
                statusDiv.textContent = '❌ 未連接到機器人';
                statusDiv.className = 'status disconnected';
                connectBtn.textContent = '連接';
                connectBtn.className = 'connect-btn connect';
            }
            
            // 啟用/停用控制按鈕
            controlBtns.forEach(btn => {
                btn.disabled = !connected;
            });
        }
        
        // WebSocket連接
        function connectWebSocket() {
            try {
                addLog(`正在連接到 ${WS_URL}...`);
                websocket = new WebSocket(WS_URL);
                
                websocket.onopen = function(event) {
                    addLog('WebSocket連接成功!', 'success');
                    updateConnectionStatus(true);
                };
                
                websocket.onmessage = function(event) {
                    addLog(`收到訊息: ${event.data}`);
                };
                
                websocket.onclose = function(event) {
                    addLog(`WebSocket連接關閉 (代碼: ${event.code})`, 'error');
                    updateConnectionStatus(false);
                };
                
                websocket.onerror = function(error) {
                    addLog(`WebSocket錯誤: ${error}`, 'error');
                    updateConnectionStatus(false);
                };
                
            } catch (error) {
                addLog(`連接失敗: ${error.message}`, 'error');
                updateConnectionStatus(false);
            }
        }
        
        // 中斷WebSocket連接
        function disconnectWebSocket() {
            if (websocket) {
                websocket.close();
                websocket = null;
            }
            updateConnectionStatus(false);
            addLog('手動中斷連接');
        }
        
        // 切換連接狀態
        function toggleConnection() {
            if (isConnected) {
                disconnectWebSocket();
            } else {
                connectWebSocket();
            }
        }
        
        // 發送控制指令
        function sendCommand(direction) {
            if (!isConnected || !websocket) {
                addLog('未連接到機器人，無法發送指令', 'error');
                return;
            }
            
            try {
                const command = {
                    direction: direction
                };
                
                const message = JSON.stringify(command);
                websocket.send(message);
                addLog(`發送指令: ${direction}`);
                
            } catch (error) {
                addLog(`發送指令失敗: ${error.message}`, 'error');
            }
        }
        
        // 鍵盤控制支援
        document.addEventListener('keydown', function(event) {
            if (!isConnected) return;
            
            switch(event.code) {
                case 'ArrowUp':
                case 'KeyW':
                    event.preventDefault();
                    sendCommand('UP');
                    break;
                case 'ArrowDown':
                case 'KeyS':
                    event.preventDefault();
                    sendCommand('DOWN');
                    break;
                case 'ArrowLeft':
                case 'KeyA':
                    event.preventDefault();
                    sendCommand('LEFT');
                    break;
                case 'ArrowRight':
                case 'KeyD':
                    event.preventDefault();
                    sendCommand('RIGHT');
                    break;
                case 'Space':
                    event.preventDefault();
                    sendCommand('STOP');
                    break;
            }
        });
        
        document.addEventListener('keyup', function(event) {
            if (!isConnected) return;
            
            switch(event.code) {
                case 'ArrowUp':
                case 'KeyW':
                case 'ArrowDown':
                case 'KeyS':
                case 'ArrowLeft':
                case 'KeyA':
                case 'ArrowRight':
                case 'KeyD':
                    event.preventDefault();
                    sendCommand('STOP');
                    break;
            }
        });
        
        // 防止觸控事件的預設行為
        document.addEventListener('touchstart', function(e) {
            if (e.target.classList.contains('control-btn')) {
                e.preventDefault();
            }
        }, { passive: false });
        
        document.addEventListener('touchend', function(e) {
            if (e.target.classList.contains('control-btn')) {
                e.preventDefault();
            }
        }, { passive: false });
        
        // 初始化
        addLog('機器人控制系統已準備就緒');
        addLog('點擊"連接"按鈕開始控制機器人');
        updateConnectionStatus(false);
    </script>
</body>
</html>
