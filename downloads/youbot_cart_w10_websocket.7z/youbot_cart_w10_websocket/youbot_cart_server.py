from controller import Robot, Keyboard  # 確保正確導入
import threading
import socket

# 常數定義
TIME_STEP = 32
MAX_VELOCITY = 6.28

# 機器人與鍵盤初始化
robot = Robot()
webots_keyboard = Keyboard()
webots_keyboard.enable(TIME_STEP)

# 設定輪子速度的函數
def set_wheel_velocity(v1, v2, v3, v4):
    # 請根據您的機器人輪子命名自行修改
    wheels = [
        robot.getDevice('wheel1'),
        robot.getDevice('wheel2'),
        robot.getDevice('wheel3'),
        robot.getDevice('wheel4')
    ]
    velocities = [v1, v2, v3, v4]
    for wheel, velocity in zip(wheels, velocities):
        wheel.setVelocity(velocity)

# WebSocket伺服器啟動
def ws_server():
    SERVER_IP = '[2001:288:6004:17:fff1:cd25:0000:a021]'  # 您的IPv6地址
    SERVER_PORT = 8081
    try:
        server = IPv6WebsocketServer(SERVER_IP, SERVER_PORT)
        server.set_on_message_received(on_message)
        print(f"WebSocket伺服器已啟動在 [{SERVER_IP}]:{SERVER_PORT}")
        server.run_forever()
    except socket.error as e:
        print(f"啟動錯誤: {e}")
        print("請檢查：1. 已關閉防火牆 2. 伺服器地址與端口設置")

# Webots主控制迴圈
def webots_main():
    print("控制說明：方向鍵控制，q/ESC退出")
    while robot.step(TIME_STEP) != -1:
        key = webots_keyboard.getKey()
        if key == Keyboard.UP:
            set_wheel_velocity(MAX_VELOCITY, MAX_VELOCITY, MAX_VELOCITY, MAX_VELOCITY)
        elif key == Keyboard.DOWN:
            set_wheel_velocity(-MAX_VELOCITY, -MAX_VELOCITY, -MAX_VELOCITY, -MAX_VELOCITY)
        elif key == Keyboard.LEFT:
            set_wheel_velocity(-MAX_VELOCITY, MAX_VELOCITY, -MAX_VELOCITY, MAX_VELOCITY)
        elif key == Keyboard.RIGHT:
            set_wheel_velocity(MAX_VELOCITY, -MAX_VELOCITY, MAX_VELOCITY, -MAX_VELOCITY)
        elif key in [ord('q'), 27]:  # 27 是 ESC 鍵
            set_wheel_velocity(0, 0, 0, 0)
            break
        else:
            set_wheel_velocity(0, 0, 0, 0)

if __name__ == "__main__":
    # 啟動WebSocket伺服器
    ws_thread = threading.Thread(target=ws_server, daemon=True)
    ws_thread.start()

    # 啟動Webots主循環
    webots_main()
    print("系統已經結束運行")
